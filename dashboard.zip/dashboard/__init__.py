"""Dashboard package root."""
